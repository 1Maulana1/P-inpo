function gantiHalaman(namaHalaman) {
    // Sembunyikan semua konten
    document.getElementById('konten-profil').style.display = 'none';
    document.getElementById('konten-alamat').style.display = 'none';

    // Tampilkan yang dipilih
    document.getElementById('konten-' + namaHalaman).style.display = 'block';
}